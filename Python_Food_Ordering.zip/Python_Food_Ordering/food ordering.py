import mysql.connector

# Connect to the MySQL database
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Aniket@2023",
    database="food"
)

cursor = db.cursor()

def display_menu():
    # Query the database for available items
    cursor.execute("SELECT * FROM items")
    items = cursor.fetchall()

    print("Menu:")
    for item in items:
        item_id, name, price = item
        print(f"{item_id}. {name} - ${price:.2f}")

def place_order(customer_id):
    display_menu()
    order_items = []

    while True:
        item_id = int(input("Enter item ID to add to the order (0 to finish): "))
        if item_id == 0:
            break
        quantity = int(input("Enter quantity: "))
        order_items.append((item_id, quantity))

    if order_items:
        cursor.execute("INSERT INTO orders (customer_id) VALUES (%s)", (customer_id,))
        order_id = cursor.lastrowid

        for item_id, quantity in order_items:
            cursor.execute("INSERT INTO order_items (order_id, item_id, quantity) VALUES (%s, %s, %s)",
                           (order_id, item_id, quantity))

        db.commit()
        print("Order placed successfully!")

def main():
    # Gather customer information (e.g., name and phone number)
    name = input("Enter your name: ")
    phone = input("Enter your phone number: ")

    cursor.execute("INSERT INTO customers (name, phone) VALUES (%s, %s)", (name, phone))
    customer_id = cursor.lastrowid
    db.commit()

    while True:
        print("\nOptions:")
        print("1. Place an order")
        print("2. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            place_order(customer_id)
        elif choice == "2":
            break
        else:
            print("Invalid choice. Please try again.")

    db.close()

if __name__ == "__main__":
    main()
